using UnityEngine;

public class Gun : MonoBehaviour
{
    private Transform gunMuzzle; 
    private void Start()
    {
        
        gunMuzzle = GetComponent<Transform>();
    }

    private void Update()
    {
       
        Vector3 mousePosition = Input.mousePosition;
        mousePosition.z = -Camera.main.transform.position.z; 
        Vector3 targetPosition = Camera.main.ScreenToWorldPoint(mousePosition);

       
        gunMuzzle.position = targetPosition;
    }
}
