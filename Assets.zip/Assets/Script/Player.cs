using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float runSpeed = 20;

    public Animator topTorso;
    public Animator botTorso;
    private float Horizontal;
    private float Vertical;
    private Rigidbody2D body;

    private bool isMoving = false;


    // Start is called before the first frame update
    void Start()
    {
        body = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        MovePlayer();
        RotateBody();
        RotateFeet();
    }

    private void FixedUpdate()
    {
        body.AddForce(new Vector2(Horizontal * runSpeed, Vertical * runSpeed));
    }

    void MovePlayer()
    {
        Horizontal = Input.GetAxisRaw("Horizontal");
        Vertical = Input.GetAxisRaw("Vertical");

        if (Horizontal != 0 || Vertical != 0)
        {
            isMoving = true;
        }
        else
        {
            isMoving = false;
        }
    }

    void RotateBody()
    {
        Vector3 difference;

        float distance = Vector3.Distance(gameObject.transform.position, Camera.main.ScreenToWorldPoint(Input.mousePosition));


        difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position ;
        difference.Normalize();

        float rotZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;
        topTorso.transform.rotation = Quaternion.Euler(0, 0, rotZ);
    }

    void RotateFeet()
    {
        if (isMoving)
        {

            botTorso.SetBool("isMoving", isMoving);

            Vector2 v = body.velocity;
            float angle = Mathf.Atan2(v.y, v.x) * Mathf.Rad2Deg;
            botTorso.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

            if (botTorso.transform.localEulerAngles.z > 90 && botTorso.transform.localEulerAngles.z > 270)
            {
                botTorso.transform.localScale = new Vector3(-1, -1, -1);

            }
            else
            {
                botTorso.transform.localScale = new Vector3(1, 1, 1);
            }

        }
        else
        {
            botTorso.SetBool("isMoving", isMoving);
        }
    }
}